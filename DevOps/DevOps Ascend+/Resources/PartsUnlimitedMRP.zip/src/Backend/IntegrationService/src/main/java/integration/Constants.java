package integration;


public class Constants {
    //Ensure that the constants file cannot be initialized.
    private Constants(){}

    public static final int SCHEDULED_INTERVAL = 30000;
}
