package smpl.ordering.repositories.mongodb.test;

public interface IntegrationTests{

}