package smpl.ordering;

/**
 * Interface for unit test hooks into various backend components.
 */
public interface TestPath
{
    public void reset();
}
