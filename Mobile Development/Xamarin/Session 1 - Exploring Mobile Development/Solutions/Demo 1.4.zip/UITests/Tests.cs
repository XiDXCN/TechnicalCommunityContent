﻿using System;
using System.IO;
using System.Linq;
using NUnit.Framework;
using Xamarin.UITest;
using Xamarin.UITest.Queries;

namespace UITests
{
    [TestFixture(Platform.Android)]
    public class Tests
    {
        IApp app;
        Platform platform;

        public Tests(Platform platform)
        {
            this.platform = platform;
        }

        [SetUp]
        public void BeforeEachTest()
        {
            app = AppInitializer.StartApp(platform);
        }

        [Test]
        public void AppLaunches()
        {
          app.Screenshot("First screen.");
        }

        [Test]
        public void PeformSyncPhotos()
        {
            app.Tap(c => c.Text("Sync Photos"));

            ///* Assert */
            var results = app.WaitForElement(q => q.Text("BigFourSummerHeat.png"));
            app.Screenshot("Photo Sync.");
            Assert.IsTrue(results.Any(), "Photos loaded from Azure");
        }
    }
}

