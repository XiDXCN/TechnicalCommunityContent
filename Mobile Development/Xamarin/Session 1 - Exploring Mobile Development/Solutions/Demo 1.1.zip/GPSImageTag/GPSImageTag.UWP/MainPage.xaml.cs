﻿
namespace GPSImageTag.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            this.InitializeComponent();
           
            LoadApplication(new GPSImageTag.App());
        }
    }
}
